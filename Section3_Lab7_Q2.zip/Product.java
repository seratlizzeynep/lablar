
public class Product {
    ExportList[] ProdList;

    public Product() {
        ProdList = new ExportList[4];
        ProdList[0] = new SaleUnit("Product1", "Version1", 2, 10);
        ProdList[1] = new SaleUnit("Product1", "Version1.1", 3, 15);
        ProdList[2] = new SaleUnit("Product2", "Version1", 2, 10, 20);
        ProdList[3] = new SaleUnit("Product2", "Version1.1", 3, 15, 30);
    }

    public void inventory() {
        System.out.println("Electronic Store Inventory");
        System.out.println("--------------------------------------------");
        for (int i = 0; i < ProdList.length; i++) {
            System.out.println(ProdList[i]);
            System.out.println("--------------------------------------------");
        }
    }

    public void exportInventory() {
        System.out.println("Electronic Store Export Inventory");
        System.out.println("--------------------------------------------");
        for (int i = 0; i < ProdList.length; i++) {
            System.out.println(ProdList[i]);
            System.out.println("The product is added to the list");
            System.out.println("--------------------------------------------");
        }
    }
}

    

