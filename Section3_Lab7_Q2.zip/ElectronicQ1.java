

public class ElectronicQ1 {
    public static void main(String[] args) {
        Product output = new Product();
        output.inventory(); 
        output.exportInventory(); 
    }
}
