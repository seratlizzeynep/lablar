
abstract public class ProductList {
    protected String Productname;    
    protected String Modeldetail;   

    public ProductList(String name, String Model) {
        Productname = name;
        Modeldetail = Model;
    }

    public String toString() {
        return "Product Name: " + Productname + "\nModel Detail: " + Modeldetail;
    }

    public abstract double price(); 
}
