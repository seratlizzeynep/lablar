
public class Export {
ExportList[] ExList;
public Export () {
ExList= new ExportList[4];
ExList[0]= new SaleUnit("Product1","Version1",2,10);
ExList[1]= new SaleUnit("Product1","Version1.1",3,15);
ExList[2]= new SaleUnit("Product2","Version1",2,10,20);
ExList[3]= new SaleUnit("Product2","Version1.1",3,15,30);
}
public void exportlist() {
System.out.println ("Electronic Store Export Inventory");
System.out.println ("--------------------------------------------");
for (int i=0; i<ExList.length;i++) {
System.out.println (ExList[i]);
System.out.println("The product is added to the list");
System.out.println ("--------------------------------------------");
}
}
}