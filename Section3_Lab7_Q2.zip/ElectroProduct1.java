

public class ElectroProduct1 extends ProductList {
    private double guaranteetime; 
    private double cost;          

   
    public ElectroProduct1(String name, String model, double time, double number) {
        super(name, model); 
        this.guaranteetime = time;
        this.cost = number;
    }

  
    @Override
    public double price() {
        return cost; 
    }

   
    @Override
    
    public String toString() {
        return "Product Name: " + Productname + " \nModel Detail: " + Modeldetail +
               " Guarantee During: " + guaranteetime;
    }



}
