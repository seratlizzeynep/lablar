

public class ElectroProduct2 extends ProductList {
    private double guaranteetime; 
    private double cost;          
    private double workrange;    

    public ElectroProduct2(String name, String model, double time, double number, double limitrange) {
        super(name, model); 
        this.guaranteetime = time;
        this.cost = number;
        this.workrange = limitrange;
    }

   
    @Override
    public double price() {
        return cost; 
    }

   
    @Override
  
    public String toString() {
        return "Product Name: " + Productname + "\nModel Detail: " + Modeldetail + " Guarantee During: " + guaranteetime + 
               " Limit Working Temperature: " + workrange + " C";
    }



}
