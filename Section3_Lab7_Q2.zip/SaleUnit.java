
public class SaleUnit extends ExportList {
    

    public SaleUnit(String name, String model, double time, double number) {
        super(name, model, time, number); 
    }

    
    public SaleUnit(String name, String model, double time, double number, double range) {
        super(name, model, time, number, range); 
    }

    @Override
    public String toString() {
        return super.toString(); 
    }
}
