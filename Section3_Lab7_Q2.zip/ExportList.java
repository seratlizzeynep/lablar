


public class ExportList {
    protected String Productname;
    protected String Modeldetail;
    protected double guaranteetime;
    protected double cost;
    protected double workrange;
    protected boolean control;

   
    public ExportList(String name, String model, double time, double number) {
        Productname = name;
        Modeldetail = model;
        guaranteetime = time;
        cost = number;
        control = false; 
    }

    
    public ExportList(String name, String model, double time, double number, double range) {
        Productname = name;
        Modeldetail = model;
        guaranteetime = time;
        cost = number;
        workrange = range;
        control = true; 
    }

    @Override
    public String toString() {
        if (control) {
            return "Product Name: " + Productname + "\nModel Detail: " + Modeldetail +
                   " Guarantee During: " + guaranteetime + " \nPrice of Device: " + cost +
                   " Limit Working Temperature: " + workrange ;
        } else {
            return "Product Name: " + Productname + "\nModel Detail: " + Modeldetail +
                   " Guarantee During: " + guaranteetime + " \nPrice of Device: " + cost;
        }
    }
}
