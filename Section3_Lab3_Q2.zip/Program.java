

public class Program implements Programinterface, Comparable<Program> {
    private String name;
    private int publishyear;
    private int programcode;
    private static int programCount = 0; 
    
    public Program(String name, int publishyear) {
        this.name = name;
        this.publishyear = publishyear;
        this.programcode = 0; 
        programCount++; 
    }

   
    public String ProgramName() {
        return this.name;
    }

    public int AgeProgram() {
        return (2024) -( this.publishyear); 
    }
   
    public static int getProgramnumber() {
        return programCount;
    }

    public int progcode(int progcoden) {
        this.programcode = programcode + progcoden;
        return this.programcode;
    }

    
    @Override
    public String toString() {
        return "Name of Program : " + this.ProgramName() + ", Age of Program : " + this.AgeProgram()
                + ", Code number of program : " + this.programcode;
    }

    
    @Override
    public int compareTo(Program other) {
        if (this.name.equals(other.name) && this.publishyear == other.publishyear) {
            return 10; 
        } else if (!this.name.equals(other.name) && this.AgeProgram() == other.AgeProgram()) {
            return 0; 
        } else if (!this.name.equals(other.name) && this.AgeProgram() < other.AgeProgram()) {
            return -1; 
        } else {
            return 1; 
        }
    }

    
    public String compareProgram(Program other) {
        int comparison = this.compareTo(other);
        if (comparison == 10) {
            return this.ProgramName() + " and " + other.ProgramName() + " are  same program";
        } else if (comparison == 0) {
            return this.ProgramName() + " and " + other.ProgramName() + " are the same age";
        } else if (comparison == -1) {
            return this.ProgramName() + " is younger than " + other.ProgramName();
        } else {
            return this.ProgramName() + " is older than " + other.ProgramName();
        }
    }
}
