

public interface Programinterface {
    public String ProgramName(); 
    public int AgeProgram(); 
    public int progcode(int progcoden); 
	
}
