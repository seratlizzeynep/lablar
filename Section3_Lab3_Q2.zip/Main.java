

public class Main {
    public static void main(String[] args) {
        Program prog1 = new Program("Program1", 2020);
        prog1.progcode(200);
        System.out.println(prog1);

        Program prog2 = new Program("Program2", 2019);
        System.out.println(prog2);

        Program prog3 = new Program("Program2", 2019);
        System.out.println(prog3);

        Program prog4 = new Program("Program4", 2019);
        System.out.println(prog4);

        System.out.println();
        System.out.println(prog1.compareProgram(prog2));
        System.out.println(prog2.compareProgram(prog3));
        System.out.println(prog2.compareProgram(prog1));
        System.out.println(prog4.compareProgram(prog3));
        System.out.println();
        System.out.println("Program number : " + Program.getProgramnumber());
    }
}

